local MM = _G.ModuloMarket
if not MM then return end

-- Forever gathering output item IDs and minimum skill requirements.
-- Primary Herbalism, Mining and Fishing outputs come from the Forever auto-learned
-- gathering skill records in ProfessionMaster 7.2.10:
--   models/skills/forever.lua ("herbs, ores and fish (auto-learned based on skill level)")
-- Secondary Mining drops come from:
--   models/mining-node-contents.lua (Vanilla node loot tables)
-- This file vendors item-ID facts only; Market does not depend on ProfessionMaster.
-- Required skill is the first (orange) threshold from the gathering skill record.
-- For secondary mining drops, it is the minimum skill of any documented source node.
-- Skinning includes the core classic leather/hide progression items whose minimum
-- profession thresholds are stable in the classic profession model. This is a
-- conservative subset, not a complete creature-to-item loot map.

MM.GatheringItems = {
    -- [itemID] = { professionID, requiredSkill }
    -- Skinning: core leather and hide tiers. Special creature leathers/scales are
    -- intentionally omitted until their exact skill gates are evidenced.
    [783] = { 393, 1 },       -- Light Hide
    [2318] = { 393, 1 },      -- Light Leather
    [4232] = { 393, 100 },    -- Medium Hide
    [2319] = { 393, 100 },    -- Medium Leather
    [4235] = { 393, 200 },    -- Heavy Hide
    [4234] = { 393, 200 },    -- Heavy Leather
    [4305] = { 393, 250 },    -- Thick Hide
    [4304] = { 393, 250 },    -- Thick Leather
    [8171] = { 393, 300 },    -- Rugged Hide
    [8170] = { 393, 300 },    -- Rugged Leather

    [765] = { 182, 1 },
    [774] = { 186, 1 },
    [785] = { 182, 50 },
    [818] = { 186, 1 },
    [1206] = { 186, 65 },
    [1210] = { 186, 1 },
    [1529] = { 186, 65 },
    [1705] = { 186, 65 },
    [2447] = { 182, 1 },
    [2449] = { 182, 15 },
    [2450] = { 182, 70 },
    [2453] = { 182, 100 },
    [2770] = { 186, 1 },
    [2771] = { 186, 65 },
    [2772] = { 186, 125 },
    [2775] = { 186, 65 },
    [2776] = { 186, 155 },
    [2835] = { 186, 1 },
    [2836] = { 186, 65 },
    [2838] = { 186, 125 },
    [3355] = { 182, 115 },
    [3356] = { 182, 125 },
    [3357] = { 182, 150 },
    [3358] = { 182, 185 },
    [3369] = { 182, 120 },
    [3818] = { 182, 160 },
    [3819] = { 182, 195 },
    [3820] = { 182, 85 },
    [3821] = { 182, 170 },
    [3858] = { 186, 175 },
    [3864] = { 186, 125 },
    [4603] = { 356, 130 },
    [4625] = { 182, 205 },
    [6289] = { 356, 1 },
    [6291] = { 356, 1 },
    [6299] = { 356, 1 },
    [6303] = { 356, 1 },
    [6308] = { 356, 1 },
    [6317] = { 356, 1 },
    [6358] = { 356, 1 },
    [6359] = { 356, 55 },
    [6361] = { 356, 1 },
    [6362] = { 356, 130 },
    [6458] = { 356, 1 },
    [6522] = { 356, 1 },
    [7909] = { 186, 125 },
    [7910] = { 186, 125 },
    [7911] = { 186, 175 },
    [7912] = { 186, 175 },
    [7973] = { 356, 205 },
    [8365] = { 356, 130 },
    [8831] = { 182, 210 },
    [8836] = { 182, 220 },
    [8838] = { 182, 230 },
    [8839] = { 182, 235 },
    [8845] = { 182, 245 },
    [8846] = { 182, 250 },
    [10620] = { 186, 245 },
    [11370] = { 186, 230 },
    [11382] = { 186, 230 },
    [11754] = { 186, 230 },
    [12238] = { 356, 1 },
    [12361] = { 186, 245 },
    [12363] = { 186, 245 },
    [12364] = { 186, 245 },
    [12365] = { 186, 245 },
    [12799] = { 186, 245 },
    [12800] = { 186, 245 },
    [13422] = { 356, 205 },
    [13463] = { 182, 270 },
    [13464] = { 182, 260 },
    [13465] = { 182, 280 },
    [13466] = { 182, 285 },
    [13467] = { 182, 290 },
    [13468] = { 182, 300 },
    [13754] = { 356, 205 },
    [13755] = { 356, 205 },
    [13756] = { 356, 205 },
    [13757] = { 356, 205 },
    [13758] = { 356, 205 },
    [13759] = { 356, 205 },
    [13760] = { 356, 205 },
    [13888] = { 356, 330 },
    [13889] = { 356, 330 },
    [13890] = { 356, 330 },
    [13893] = { 356, 330 },
    [248815] = { 186, 300 },
}
